#include <stdio.h>

#define INPUT_FILE "./input/if1"

int main(int argc, char * argv[]) {
    
    return 0;
}
